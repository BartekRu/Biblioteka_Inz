Look for the full dataset?
Please visit the [websit](https://snap.stanford.edu/data/loc-gowalla.html).
